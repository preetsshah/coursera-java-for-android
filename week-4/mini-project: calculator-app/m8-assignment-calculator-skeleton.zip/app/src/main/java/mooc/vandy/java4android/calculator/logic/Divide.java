package mooc.vandy.java4android.calculator.logic;

/**
 * Perform the Divide operation.
 */
public class Divide {
    // TODO -- start your code here

    //input operands
    private int mArgumentOne = 0;
    private int mArgumentTwo = 0;

    //constructor
    public Divide(int argumentOne, int argumentTwo) {
        mArgumentOne = argumentOne;
        mArgumentTwo = argumentTwo;
    }

    //returning answer
    public String toString() {
        //returning division's quotient and remainder
        return String.valueOf(mArgumentOne / mArgumentTwo) +
                " R:" + String.valueOf(mArgumentOne % mArgumentTwo);
    }
}
